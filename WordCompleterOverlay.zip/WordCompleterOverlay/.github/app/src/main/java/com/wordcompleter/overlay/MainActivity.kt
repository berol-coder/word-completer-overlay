package com.wordcompleter.overlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.gravity = Gravity.CENTER
        layout.setPadding(60, 160, 60, 60)

        val title = TextView(this)
        title.text = "Word Completer"
        title.textSize = 22f
        layout.addView(title)

        val info = TextView(this)
        info.text = "1. Grant the overlay permission.\n" +
            "2. Start the floating suggestion window.\n" +
            "Then switch to Roblox: the panel and the suggested-word box float on top."
        info.setPadding(0, 30, 0, 50)
        layout.addView(info)

        val permissionButton = Button(this)
        permissionButton.text = "Grant overlay permission"
        permissionButton.setOnClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
        layout.addView(permissionButton)

        val startButton = Button(this)
        startButton.text = "Start Word Completer"
        startButton.setOnClickListener {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, OverlayService::class.java))
                Toast.makeText(this, "Started. You can switch to Roblox now.", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Grant the overlay permission first.", Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(startButton)

        setContentView(layout)
    }
}
