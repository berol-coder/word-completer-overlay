package com.wordcompleter.overlay

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer
import kotlin.math.abs
import kotlin.math.min
import kotlin.random.Random

/**
 * Floating overlay version of the Word Completer Suggestion Mode.
 * No key tracking and no automatic typing: it only shows a suggested
 * word that you type manually in the game, same as the Lua/AHK versions.
 *
 * NOT compiled or tested in this environment (no Android SDK / network
 * access here) -- build and fix any issues in Android Studio.
 */
class OverlayService : Service() {

    companion object {
        const val WORDS_URL =
            "https://raw.githubusercontent.com/lunatic2027777-glitch/dataset/refs/heads/main/alos.txt"
        const val VERSION_URL =
            "https://raw.githubusercontent.com/lunatic2027777-glitch/dataset/refs/heads/main/mov.txt"
        const val PREFS = "word_completer_prefs"
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    // ---- Dictionary -------------------------------------------------------
    private val words = ArrayList<String>()
    private val norm = ArrayList<String>()
    private val lens = ArrayList<Int>()
    private val bucket1 = HashMap<Char, ArrayList<Int>>()
    private val bucket2 = HashMap<String, ArrayList<Int>>()
    private var usedIdx = BooleanArray(0)
    private var usedCount = 0
    private var dictionaryReady = false

    private var currentRawWord = ""
    private var currentWord = ""
    private var basePrefix = ""

    // ---- Settings -----------------------------------------------------------
    private val suffixValues = Array(9) { "" }
    private val suffixEnabled = BooleanArray(9)
    private var minLengthEnabled = false
    private var minLength = 10
    private var excludeEnabled = false
    private var excludeEnding = ""

    // ---- Views --------------------------------------------------------------
    private var panelView: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var suggestionView: LinearLayout? = null
    private var restoreView: Button? = null

    private lateinit var prefixBox: EditText
    private lateinit var statusText: TextView
    private lateinit var countText: TextView
    private val suffixBoxes = arrayOfNulls<EditText>(9)
    private val suffixChecks = arrayOfNulls<CheckBox>(9)
    private val suffixIndicators = arrayOfNulls<View>(9)
    private lateinit var excludeBox: EditText
    private lateinit var excludeCheck: CheckBox
    private lateinit var minBox: EditText
    private lateinit var minCheck: CheckBox
    private lateinit var longInfo: TextView

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        loadSettings()
        buildRestoreBar()
        buildPanel()
        setMinimized(false)
        checkVersionThenLoadWords()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        safeRemove(panelView)
        safeRemove(suggestionView)
        safeRemove(restoreView)
    }

    private fun safeRemove(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (_: Exception) { }
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    // ---- Settings persistence (SharedPreferences instead of a settings file) --
    private fun prefs(): SharedPreferences = getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun loadSettings() {
        val p = prefs()
        for (i in 0 until 9) {
            suffixValues[i] = p.getString("suffix_$i", "") ?: ""
            suffixEnabled[i] = p.getBoolean("suffix_on_$i", false)
        }
        minLengthEnabled = p.getBoolean("min_on", false)
        minLength = p.getInt("min_len", 10)
        excludeEnabled = p.getBoolean("exclude_on", false)
        excludeEnding = p.getString("exclude_end", "") ?: ""
    }

    private fun saveSettings() {
        val e = prefs().edit()
        for (i in 0 until 9) {
            e.putString("suffix_$i", suffixValues[i])
            e.putBoolean("suffix_on_$i", suffixEnabled[i])
        }
        e.putBoolean("min_on", minLengthEnabled)
        e.putInt("min_len", minLength)
        e.putBoolean("exclude_on", excludeEnabled)
        e.putString("exclude_end", excludeEnding)
        e.apply()
    }

    // ---- Text helpers ---------------------------------------------------------
    private fun normalize(s: String): String {
        val d = Normalizer.normalize(s, Normalizer.Form.NFD)
        return d.replace(Regex("\\p{Mn}+"), "")
    }

    private fun levenshtein(a: String, b: String, bound: Int): Int {
        val n = a.length
        val m = b.length
        if (abs(n - m) > bound) return bound + 1
        if (n == 0) return m
        if (m == 0) return n
        var prev = IntArray(m + 1) { it }
        var cur = IntArray(m + 1)
        for (i in 1..n) {
            cur[0] = i
            var rowMin = i
            val ai = a[i - 1]
            for (j in 1..m) {
                val cost = if (ai == b[j - 1]) 0 else 1
                var v = prev[j] + 1
                val x1 = cur[j - 1] + 1
                if (x1 < v) v = x1
                val x2 = prev[j - 1] + cost
                if (x2 < v) v = x2
                cur[j] = v
                if (v < rowMin) rowMin = v
            }
            if (rowMin > bound) return bound + 1
            val tmp = prev; prev = cur; cur = tmp
        }
        return prev[m]
    }

    // ---- Word list loading ------------------------------------------------
    private fun checkVersionThenLoadWords() {
        Thread {
            try {
                val status = httpGet(VERSION_URL).trim()
                if (status.none { it.isLetter() }) {
                    handler.post { showExpired() }
                    return@Thread
                }
            } catch (ex: Exception) {
                handler.post {
                    Toast.makeText(this, "Could not verify version: ${ex.message}", Toast.LENGTH_LONG).show()
                    stopSelf()
                }
                return@Thread
            }
            try {
                val body = httpGet(WORDS_URL).trim()
                if (body.none { it.isLetter() }) throw Exception("This build has been remotely disabled.")
                if (body.contains("<html", true) || body.contains("Cloudflare")) {
                    throw Exception("GitHub returned an HTML/protection page instead of the word list.")
                }
                val seen = HashSet<String>()
                for (part in body.split(",")) {
                    val w = part.trim()
                    if (w.isNotEmpty() && seen.add(w)) {
                        val n = normalize(w).lowercase()
                        val idx = words.size
                        words.add(w)
                        norm.add(n)
                        lens.add(n.length)
                        if (n.isNotEmpty()) {
                            bucket1.getOrPut(n[0]) { ArrayList() }.add(idx)
                        }
                        if (n.length >= 2) {
                            bucket2.getOrPut(n.substring(0, 2)) { ArrayList() }.add(idx)
                        }
                    }
                }
                if (words.isEmpty()) throw Exception("No valid words found.")
                usedIdx = BooleanArray(words.size)
                dictionaryReady = true
                handler.post {
                    setStatus("Ready. Enter a Prefix and press ENTER to generate a suggestion.", "#A0C8EB")
                    refreshIndicators()
                }
            } catch (ex: Exception) {
                handler.post {
                    setStatus("Could not load word list: ${ex.message}", "#FF7066")
                }
            }
        }.start()
    }

    private fun httpGet(urlStr: String): String {
        val url = URL(urlStr)
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.setRequestProperty("Cache-Control", "no-cache")
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        conn.inputStream.bufferedReader().use { return it.readText() }
    }

    private fun getBucket(prefix: String): ArrayList<Int>? {
        if (prefix.length >= 2) return bucket2[prefix.substring(0, 2)]
        if (prefix.isNotEmpty()) return bucket1[prefix[0]]
        return null
    }

    // ---- UI building helpers ------------------------------------------------
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun pillBackground(fill: Int, stroke: Int = Color.TRANSPARENT, radius: Float = dp(6).toFloat()): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(fill)
        d.cornerRadius = radius
        if (stroke != Color.TRANSPARENT) d.setStroke(dp(1), stroke)
        return d
    }

    private fun makeEditText(hint: String, text: String = ""): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(text)
        e.setTextColor(Color.WHITE)
        e.setHintTextColor(Color.parseColor("#82909B"))
        e.background = pillBackground(Color.parseColor("#1F2530"), Color.parseColor("#42495A"), dp(4).toFloat())
        e.setPadding(dp(8), dp(4), dp(8), dp(4))
        e.setSingleLine(true)
        return e
    }

    private fun makeButton(text: String): Button {
        val b = Button(this)
        b.text = text
        b.setTextColor(Color.WHITE)
        b.background = pillBackground(Color.parseColor("#303A48"))
        b.setPadding(dp(10), dp(6), dp(10), dp(6))
        b.isAllCaps = false
        b.minWidth = 0
        b.minimumWidth = 0
        return b
    }

    private fun makeLabel(text: String, color: Int = Color.parseColor("#EBEEF2"), size: Float = 13f): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(color)
        t.textSize = size
        return t
    }

    private fun makeCheck(initial: Boolean): CheckBox {
        val c = CheckBox(this)
        c.isChecked = initial
        return c
    }

    private fun overlayParams(w: Int, h: Int, gravity: Int, focusable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!focusable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        val p = WindowManager.LayoutParams(w, h, overlayType(), flags, PixelFormat.TRANSLUCENT)
        p.gravity = gravity
        return p
    }

    private fun makeDraggable(view: View, params: WindowManager.LayoutParams, handleView: View) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        handleView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    try { wm.updateViewLayout(view, params) } catch (_: Exception) { }
                    true
                }
                else -> false
            }
        }
    }

    private fun simpleWatcher(onChange: () -> Unit) = object : TextWatcher {
        override fun afterTextChanged(s: Editable?) { onChange() }
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
    }

    // ---- Restore bar (shown while the panel is minimized) --------------------
    private fun buildRestoreBar() {
        val b = makeButton("Restore settings")
        b.textSize = 12f
        b.setOnClickListener { setMinimized(false) }
        // Top-right corner, out of the way of the centered suggestion box.
        val params = overlayParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.END,
            focusable = false
        )
        params.x = dp(8)
        params.y = dp(4)
        restoreView = b
        wm.addView(b, params)
        b.visibility = View.GONE
    }

    // ---- Settings panel --------------------------------------------------
    private fun buildPanel() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = pillBackground(Color.parseColor("#1B2028"), Color.parseColor("#4C5766"), dp(8).toFloat())
        root.setPadding(dp(12), dp(10), dp(12), dp(10))

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        val title = makeLabel("WORD COMPLETER", size = 15f)
        title.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        val minimizeBtn = makeButton("—")
        minimizeBtn.setOnClickListener { setMinimized(true) }
        header.addView(title)
        header.addView(minimizeBtn)
        root.addView(header)

        val prefixRow = LinearLayout(this)
        prefixRow.orientation = LinearLayout.HORIZONTAL
        prefixRow.addView(makeLabel("Prefix:"))
        prefixBox = makeEditText("Starting letters")
        prefixBox.layoutParams = LinearLayout.LayoutParams(dp(200), LinearLayout.LayoutParams.WRAP_CONTENT)
        prefixRow.addView(prefixBox)
        root.addView(prefixRow)

        root.addView(makeLabel("Suffix (select one):", size = 12f))
        val keyLabels = arrayOf("7", "8", "9", "4", "5", "6", "1", "2", "3")
        for (row in 0 until 3) {
            val rowLayout = LinearLayout(this)
            rowLayout.orientation = LinearLayout.HORIZONTAL
            for (col in 0 until 3) {
                val i = row * 3 + col
                val cell = LinearLayout(this)
                cell.orientation = LinearLayout.HORIZONTAL
                cell.setPadding(dp(2), dp(2), dp(6), dp(2))
                cell.addView(makeLabel(keyLabels[i], size = 10f))

                val check = makeCheck(suffixEnabled[i])
                suffixChecks[i] = check

                val box = makeEditText("ending", suffixValues[i])
                box.layoutParams = LinearLayout.LayoutParams(dp(70), LinearLayout.LayoutParams.WRAP_CONTENT)
                suffixBoxes[i] = box

                // Thin vertical indicator bar, right next to its own box.
                val indicator = View(this)
                indicator.layoutParams = LinearLayout.LayoutParams(dp(4), dp(22))
                indicator.setBackgroundColor(Color.parseColor("#505864"))
                suffixIndicators[i] = indicator

                check.setOnCheckedChangeListener { _, isChecked ->
                    if (isChecked) {
                        for (j in 0 until 9) if (j != i) suffixChecks[j]?.isChecked = false
                    }
                    for (j in 0 until 9) suffixEnabled[j] = suffixChecks[j]?.isChecked == true
                    saveSettings(); refreshIndicators()
                }
                box.addTextChangedListener(simpleWatcher {
                    suffixValues[i] = box.text.toString()
                    saveSettings(); refreshIndicators()
                })

                cell.addView(check)
                cell.addView(box)
                cell.addView(indicator)
                rowLayout.addView(cell)
            }
            root.addView(rowLayout)
        }

        val excludeRow = LinearLayout(this)
        excludeRow.orientation = LinearLayout.HORIZONTAL
        excludeRow.addView(makeLabel("Do not end with:"))
        excludeCheck = makeCheck(excludeEnabled)
        excludeCheck.setOnCheckedChangeListener { _, isChecked ->
            excludeEnabled = isChecked; saveSettings(); refreshIndicators()
        }
        excludeBox = makeEditText("ending to avoid", excludeEnding)
        excludeBox.addTextChangedListener(simpleWatcher {
            excludeEnding = excludeBox.text.toString(); saveSettings(); refreshIndicators()
        })
        excludeRow.addView(excludeCheck)
        excludeRow.addView(excludeBox)
        root.addView(excludeRow)

        val minRow = LinearLayout(this)
        minRow.orientation = LinearLayout.HORIZONTAL
        minCheck = makeCheck(minLengthEnabled)
        minCheck.setOnCheckedChangeListener { _, isChecked ->
            minLengthEnabled = isChecked; saveSettings(); refreshIndicators()
        }
        minRow.addView(minCheck)
        minRow.addView(makeLabel("Minimum word length"))
        minBox = makeEditText("10", minLength.toString())
        minBox.inputType = InputType.TYPE_CLASS_NUMBER
        minBox.layoutParams = LinearLayout.LayoutParams(dp(50), LinearLayout.LayoutParams.WRAP_CONTENT)
        minBox.addTextChangedListener(simpleWatcher {
            minLength = minBox.text.toString().toIntOrNull()?.takeIf { it > 0 } ?: 10
            saveSettings(); refreshIndicators()
        })
        longInfo = makeLabel("Max: - | Available: -", size = 10f)
        minRow.addView(minBox)
        minRow.addView(longInfo)
        root.addView(minRow)

        val actionRow = LinearLayout(this)
        actionRow.orientation = LinearLayout.HORIZONTAL
        val enterBtn = makeButton("ENTER")
        enterBtn.setOnClickListener { generateSuggestion() }
        val nextBtn = makeButton("Next Variant")
        nextBtn.setOnClickListener { nextVariant() }
        actionRow.addView(enterBtn)
        actionRow.addView(nextBtn)
        root.addView(actionRow)

        val resetRow = LinearLayout(this)
        resetRow.orientation = LinearLayout.HORIZONTAL
        val resetBtn = makeButton("RESET USED WORDS")
        resetBtn.setOnClickListener { resetUsed() }
        countText = makeLabel("Used: 0", size = 10f)
        resetRow.addView(resetBtn)
        resetRow.addView(countText)
        root.addView(resetRow)

        statusText = makeLabel("Loading word list...", size = 10f, color = Color.parseColor("#AEB9C7"))
        root.addView(statusText)

        prefixBox.addTextChangedListener(simpleWatcher { refreshIndicators() })
        // Pressing Enter/Go/Send on the on-screen keyboard works like the ENTER button.
        prefixBox.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE ||
                actionId == EditorInfo.IME_ACTION_GO ||
                actionId == EditorInfo.IME_ACTION_SEND ||
                actionId == EditorInfo.IME_ACTION_NEXT
            ) {
                generateSuggestion(); true
            } else false
        }

        val params = overlayParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.END,
            focusable = true
        )
        params.x = dp(8)
        params.y = dp(8)
        panelView = root
        panelParams = params
        wm.addView(root, params)
        makeDraggable(root, params, header)
    }

    private fun setStatus(msg: String, colorHex: String? = null) {
        statusText.text = msg
        if (colorHex != null) statusText.setTextColor(Color.parseColor(colorHex))
    }

    private fun setMinimized(min: Boolean) {
        panelView?.visibility = if (min) View.GONE else View.VISIBLE
        restoreView?.visibility = if (min) View.VISIBLE else View.GONE
    }

    // ---- Suggestion overlay: one at a time, destroyed and rebuilt each time --
    private fun destroySuggestion() {
        safeRemove(suggestionView)
        suggestionView = null
    }

    private fun buildSuggestion(word: String) {
        destroySuggestion()
        val display = normalize(word).uppercase()
        if (display.isEmpty()) return

        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        container.background = pillBackground(Color.parseColor("#20252C"), Color.parseColor("#49535F"), dp(8).toFloat())
        container.setPadding(dp(9), dp(6), dp(9), dp(6))

        val title = makeLabel("SUGGESTED WORD", size = 10f, color = Color.parseColor("#B1BBC8"))
        title.gravity = Gravity.CENTER
        title.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        container.addView(title)

        // Up to 20 letters per row; a longer word wraps onto a second row
        // instead of shrinking the cells further.
        val perRow = min(display.length, 20)
        var i = 0
        while (i < display.length) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_HORIZONTAL
            val end = min(i + perRow, display.length)
            for (j in i until end) {
                val cell = TextView(this)
                cell.text = display[j].toString()
                cell.setTextColor(Color.parseColor("#141820"))
                cell.background = pillBackground(Color.parseColor("#F5F5F5"), radius = dp(3).toFloat())
                cell.gravity = Gravity.CENTER
                cell.textSize = 14f
                cell.setTypeface(cell.typeface, Typeface.BOLD)
                val lp = LinearLayout.LayoutParams(dp(24), dp(28))
                lp.setMargins(dp(1), dp(1), dp(1), dp(1))
                cell.layoutParams = lp
                row.addView(cell)
            }
            container.addView(row)
            i = end
        }

        // Centered at the very top of the screen, clear of the top-right Restore button.
        val params = overlayParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL,
            focusable = false
        )
        params.y = dp(4)
        suggestionView = container
        wm.addView(container, params)
    }

    private fun showExpired() {
        val t = TextView(this)
        t.text = "This version has been remotely disabled.\n" +
            "Contact: simondice761@outlook.com\n" +
            "Discord: https://discord.gg/XY7KcDAG3z"
        t.setTextColor(Color.WHITE)
        t.background = pillBackground(Color.parseColor("#1B1B1B"), Color.parseColor("#4C5766"), dp(8).toFloat())
        t.setPadding(dp(16), dp(16), dp(16), dp(16))
        val params = overlayParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            Gravity.CENTER,
            focusable = false
        )
        wm.addView(t, params)
        panelView?.visibility = View.GONE
        restoreView?.visibility = View.GONE
    }

    // ---- Core logic, ported from the Lua script ----------------------------
    private fun getActiveSuffix(): String {
        for (i in 0 until 9) {
            if (suffixEnabled[i]) {
                val s = suffixBoxes[i]?.text?.toString()?.trim() ?: ""
                if (s.isNotEmpty()) return normalize(s).lowercase()
            }
        }
        return ""
    }

    private fun collectPool(prefix: String, suffix: String, useExclude: Boolean, exclude: String): ArrayList<Int> {
        val preferred = ArrayList<Int>()
        val fallback = ArrayList<Int>()
        val list = getBucket(prefix) ?: return preferred
        val plen = prefix.length
        val slen = suffix.length
        val elen = exclude.length
        val checkEx = useExclude && elen > 0
        for (idx in list) {
            if (!usedIdx[idx]) {
                val w = norm[idx]
                val len = lens[idx]
                if ((plen <= 1 || w.startsWith(prefix)) &&
                    (slen == 0 || (len >= slen && w.endsWith(suffix)))
                ) {
                    if (checkEx && len >= elen && w.endsWith(exclude)) {
                        fallback.add(idx)
                    } else {
                        preferred.add(idx)
                    }
                }
            }
        }
        return if (preferred.isNotEmpty()) preferred else fallback
    }

    private fun refreshIndicators() {
        if (!dictionaryReady) return
        countText.text = "Used: $usedCount"
        val prefix = normalize(prefixBox.text.toString().trim()).lowercase()
        if (prefix.isEmpty()) {
            longInfo.text = "Max: - | Available: -"
            for (i in 0 until 9) suffixIndicators[i]?.setBackgroundColor(Color.parseColor("#505864"))
            return
        }
        val list = getBucket(prefix)
        if (list == null) {
            longInfo.text = "Max: 0 | Available: 0"
            for (i in 0 until 9) suffixIndicators[i]?.setBackgroundColor(Color.parseColor("#505864"))
            return
        }
        val suffixes = Array(9) { normalize(suffixBoxes[it]?.text?.toString()?.trim() ?: "").lowercase() }
        val activeSuffix = getActiveSuffix()
        val minLen = minLength
        val plen = prefix.length

        Thread {
            val found = BooleanArray(9)
            var maxLen = 0
            var available = 0
            for (idx in list) {
                if (!usedIdx[idx]) {
                    val w = norm[idx]
                    if (plen <= 1 || w.startsWith(prefix)) {
                        val len = lens[idx]
                        for (i in 0 until 9) {
                            val s = suffixes[i]
                            if (!found[i] && s.isNotEmpty() && len >= s.length && w.endsWith(s)) found[i] = true
                        }
                        if (activeSuffix.isEmpty() || (len >= activeSuffix.length && w.endsWith(activeSuffix))) {
                            if (len > maxLen) maxLen = len
                            if (len >= minLen) available++
                        }
                    }
                }
            }
            handler.post {
                for (i in 0 until 9) {
                    suffixIndicators[i]?.setBackgroundColor(
                        Color.parseColor(if (found[i]) "#23BE5F" else "#505864")
                    )
                }
                longInfo.text = "Max: $maxLen | Available: $available"
            }
        }.start()
    }

    private var lastGenerate = 0L
    private fun generateSuggestion() {
        val now = System.currentTimeMillis()
        if (now - lastGenerate < 300) return // ignore double-fired taps on mobile
        lastGenerate = now

        if (!dictionaryReady) {
            setStatus("Word list is still loading.", "#FF8266"); return
        }
        val prefix = prefixBox.text.toString().trim()
        if (prefix.isEmpty()) {
            setStatus("Enter a prefix first.", "#FF8266"); return
        }
        val nprefix = normalize(prefix).lowercase()
        val suffix = getActiveSuffix()
        val exclude = normalize(excludeBox.text.toString().trim()).lowercase()

        var pool = collectPool(nprefix, suffix, excludeEnabled, exclude)
        if (pool.isEmpty()) {
            setStatus("No unused words match this prefix and Suffix.", "#FF8266"); return
        }

        var notice = ""
        if (minLengthEnabled) {
            val filtered = ArrayList<Int>()
            val lengthsSeen = HashSet<Int>()
            for (idx in pool) {
                if (lens[idx] >= minLength) filtered.add(idx)
                lengthsSeen.add(lens[idx])
            }
            pool = if (filtered.isNotEmpty()) {
                filtered
            } else {
                notice = "No words with $minLength+ letters; using the 3 longest lengths."
                val allowed = lengthsSeen.sortedDescending().take(3).toHashSet()
                ArrayList(pool.filter { allowed.contains(lens[it]) })
            }
        }

        if (pool.isEmpty()) {
            setStatus("No available word could be selected.", "#FF8266"); return
        }
        val chosenIdx = pool[Random.nextInt(pool.size)]
        usedIdx[chosenIdx] = true
        usedCount++
        currentRawWord = words[chosenIdx]
        currentWord = normalize(currentRawWord)
        basePrefix = prefix

        buildSuggestion(currentWord) // destroys the old box and builds the new one
        refreshIndicators()
        setStatus(
            "Suggestion ready: $currentRawWord. Type it manually in the game." +
                if (notice.isNotEmpty()) "\n$notice" else "",
            "#82DCA0"
        )
        setMinimized(true)
    }

    private var variantBusy = false
    private fun nextVariant() {
        if (variantBusy) return
        if (currentRawWord.isEmpty() || basePrefix.isEmpty()) {
            setStatus("Generate a word first, then use Next Variant.", "#FF8266")
            setMinimized(false)
            return
        }
        variantBusy = true
        val current = normalize(currentRawWord).lowercase()
        val prefix = normalize(basePrefix).lowercase()
        val plen = prefix.length
        val list = getBucket(prefix)

        Thread {
            var best = ArrayList<Int>()
            var bestDist = Int.MAX_VALUE
            var bestLenDiff = Int.MAX_VALUE
            if (list != null) {
                for (idx in list) {
                    if (!usedIdx[idx]) {
                        val candidate = norm[idx]
                        if (candidate != current && (plen <= 1 || candidate.startsWith(prefix))) {
                            val lenDiff = abs(current.length - lens[idx])
                            if (lenDiff <= bestDist) {
                                val dist = levenshtein(current, candidate, bestDist)
                                if (dist < bestDist || (dist == bestDist && lenDiff < bestLenDiff)) {
                                    bestDist = dist; bestLenDiff = lenDiff
                                    best = ArrayList(); best.add(idx)
                                } else if (dist == bestDist && lenDiff == bestLenDiff) {
                                    best.add(idx)
                                }
                            }
                        }
                    }
                }
            }
            handler.post {
                variantBusy = false
                if (best.isEmpty()) {
                    setStatus("No more unused variants are available for this prefix.", "#FF8266")
                    setMinimized(false)
                    return@post
                }
                val chosenIdx = best[Random.nextInt(best.size)]
                usedIdx[chosenIdx] = true
                usedCount++
                currentRawWord = words[chosenIdx]
                currentWord = normalize(currentRawWord)
                buildSuggestion(currentWord)
                refreshIndicators()
                setStatus("New suggestion: $currentRawWord. Type it manually.", "#82DCA0")
                setMinimized(true) // matches ENTER's behavior
            }
        }.start()
    }

    private fun resetUsed() {
        if (!dictionaryReady) return
        for (i in usedIdx.indices) usedIdx[i] = false
        usedCount = 0
        currentRawWord = ""; currentWord = ""; basePrefix = ""
        destroySuggestion()
        refreshIndicators()
        setStatus("Used words reset. All loaded words are available again.", "#82DCA0")
    }
}
